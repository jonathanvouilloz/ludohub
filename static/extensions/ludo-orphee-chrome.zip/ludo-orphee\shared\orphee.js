import { isAllowedUrl } from "./config.js";

export function orpheePayload(submission) {
  const formatPhone = (value) => {
    if (!value) return null;
    const digits = value.replace(/\D/g, "");
    if (digits.startsWith("41") && digits.length >= 11) return `0${digits.slice(2)}`.replace(/(\d{3})(\d{3})(\d{2})(\d{2})/, "$1 $2 $3 $4");
    return value;
  };
  const gender = { female: "1", male: "2", other: "4", unspecified: null }[submission.responsible.gender] ?? null;
  return {
    responsible: {
      ...submission.responsible,
      gender,
      lastName: submission.responsible.lastName.toUpperCase(),
      phone: formatPhone(submission.responsible.phone),
      secondaryPhone: formatPhone(submission.responsible.secondaryPhone),
      birthDate: submission.responsible.birthDate?.replace(/\./g, "/") ?? null,
      country: "Suisse",
    },
    members: submission.members.map((member) => ({ ...member })),
  };
}

export function injectionRequest(tabUrl, allowedOrigins, submission) {
  if (!isAllowedUrl(tabUrl, allowedOrigins)) throw new Error("orphee_url_not_allowed");
  return { type: "fill-orphee", payload: orpheePayload(submission) };
}

export function fillOrpheeDocument(payload) {
  const set = (selectors, value) => {
    if (value == null) return;
    const element = selectors.map((selector) => document.querySelector(selector)).find(Boolean);
    if (!element || !(element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement)) return;
    element.value = String(value);
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const r = payload.responsible;
  set(["#ctl00_cph1_fadh_formDDL30", "[name='gender']", "[name='genre']"], r.gender);
  set(["#ctl00_cph1_fadh_formTB34", "[name='lastName']", "[name='nom']"], r.lastName);
  set(["#ctl00_cph1_fadh_formTB35", "[name='firstName']", "[name='prenom']"], r.firstName);
  set(["#ctl00_cph1_fadh_formTB36", "[name='address']", "[name='adresse']"], r.address);
  set(["#ctl00_cph1_fadh_formCP31", "[name='postalCode']", "[name='npa']"], r.postalCode);
  set(["#ctl00_cph1_fadh_formTB38", "[name='city']", "[name='ville']"], r.city);
  set(["#ctl00_cph1_fadh_formTB1004", "[name='phone']", "[name='telephone']"], r.phone);
  set(["#ctl00_cph1_fadh_formTB1010", "[name='mobile']", "[name='portable']"], r.secondaryPhone ?? r.phone);
  set(["#ctl00_cph1_fadh_formMEL48", "[name='email']"], r.email);
  set(["#ctl00_cph1_fadh_formSD17", "[name='birthDate']", "[name='dateNaissance']"], r.birthDate);
  set(["#ctl00_cph1_fadh_formTB33", "[name='country']", "[name='pays']"], r.country);
}
