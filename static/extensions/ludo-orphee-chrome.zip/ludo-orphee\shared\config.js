import { boundFetch } from "./http.js";

const HTTPS_ORIGIN = /^https:\/\/[a-z0-9.-]+(?::\d+)?$/i;

export function safeOrigin(value) {
  if (typeof value !== "string" || !HTTPS_ORIGIN.test(value)) return null;
  try {
    const url = new URL(value);
    if (url.username || url.password || url.pathname !== "/" || url.search || url.hash) return null;
    return url.origin;
  } catch {
    return null;
  }
}

export function validateConfig(input) {
  const ludohubOrigin = safeOrigin(input?.ludohubOrigin);
  const orpheeOrigins = Array.isArray(input?.orpheeOrigins)
    ? [...new Set(input.orpheeOrigins.map(safeOrigin).filter(Boolean))]
    : [];
  if (!ludohubOrigin || ludohubOrigin.endsWith(".invalid") || orpheeOrigins.some((origin) => origin.endsWith(".invalid"))) {
    throw new Error("configuration_required");
  }
  return Object.freeze({ ludohubOrigin, orpheeOrigins: Object.freeze(orpheeOrigins) });
}

export function isAllowedUrl(value, origins) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && origins.includes(url.origin);
  } catch {
    return false;
  }
}

export async function loadConfig(runtime = globalThis.chrome?.runtime ?? globalThis.browser?.runtime, fetchImpl = fetch) {
  if (!runtime?.getURL) throw new Error("runtime_unavailable");
  const response = await boundFetch(fetchImpl)(runtime.getURL("config.local.json"), { cache: "no-store" });
  if (!response.ok) throw new Error("configuration_required");
  return validateConfig(await response.json());
}
