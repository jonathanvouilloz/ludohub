import { loadConfig } from "./shared/config.js";
import { tokenStore } from "./shared/storage.js";
import { DeviceAuth, AuthenticatedFetch, parseSession } from "./shared/auth.js";
import { FamilyApi } from "./shared/api.js";
import { ApiError } from "./shared/http.js";
import { orpheePayload } from "./shared/orphee.js";

const webext = globalThis.chrome ?? globalThis.browser;
const elements = Object.fromEntries([...document.querySelectorAll("[id]")].map((node) => [node.id, node]));
let config;
let auth;
let api;
let selected = null;
let ludoName = null;
let linkedSlug = null;

function show(node, visible) { node.hidden = !visible; }
function status(message = "") { elements["workspace-status"].textContent = message; }
function addPair(list, label, value) {
  if (!value) return;
  const dt = document.createElement("dt"); dt.textContent = label;
  const dd = document.createElement("dd"); dd.textContent = value;
  list.append(dt, dd);
}

function selectedSlug() { return elements.ludo.value; }
function selectedName() { return elements.ludo.selectedOptions[0]?.textContent || ludoName || ""; }
function selectedLogo() { return elements.ludo.selectedOptions[0]?.dataset.logo || ""; }
function selectedContact() {
  const option = elements.ludo.selectedOptions[0];
  return { address: option?.dataset.address || "", phone: option?.dataset.phone || "", email: option?.dataset.email || "", website: option?.dataset.website || "" };
}
function updateLudoNote() {
  const foreign = Boolean(selectedSlug() && linkedSlug && selectedSlug() !== linkedSlug);
  elements["ludo-note"].hidden = !foreign;
  elements["ludo-note"].textContent = foreign
    ? "Les demandes affichées sont celles de cette ludothèque. Le marquage et le paiement restent sur la ludothèque liée au poste."
    : "";
}

function clearDetail() {
  selected = null;
  elements.responsible.replaceChildren();
  elements.members.replaceChildren();
  elements.snapshots.replaceChildren();
  show(elements.detail, false);
}

function renderDetail(submission) {
  clearDetail();
  selected = submission;
  elements["detail-title"].textContent = `${submission.responsible.firstName} ${submission.responsible.lastName}`;
  addPair(elements.responsible, "E-mail", submission.responsible.email);
  addPair(elements.responsible, "Téléphone", submission.responsible.phone);
  addPair(elements.responsible, "Adresse", [submission.responsible.address, submission.responsible.postalCode, submission.responsible.city].filter(Boolean).join(", "));
  addPair(elements.responsible, "Site", submission.site.name);
  if (!submission.members.length) {
    const li = document.createElement("li");
    li.textContent = "Aucun autre membre. La personne responsable est déjà incluse.";
    elements.members.append(li);
  }
  for (const member of submission.members) {
    const li = document.createElement("li");
    li.textContent = [member.firstName, member.lastName].filter(Boolean).join(" ");
    elements.members.append(li);
  }
  if (submission.consent) {
    const heading = document.createElement("h3"); heading.textContent = "Consentement et documents";
    const label = document.createElement("p"); label.textContent = submission.consent.label;
    elements.snapshots.append(heading, label);
    for (const documentSnapshot of submission.consent.documents) {
      const p = document.createElement("p"); p.textContent = `${documentSnapshot.title} — ${documentSnapshot.version}`; elements.snapshots.append(p);
    }
  }
  elements.process.disabled = selectedSlug() !== linkedSlug || submission.status === "processed";
  show(elements.detail, true);
}

async function loadList() {
  clearDetail(); status();
  api.ludoSlug = selectedSlug();
  const result = await api.list();
  elements.submissions.replaceChildren();
  for (const summary of result.submissions) {
    if (!summary || typeof summary.id !== "string") continue;
    const li = document.createElement("li");
    const button = document.createElement("button"); button.type = "button";
    button.dataset.id = summary.id;
    const person = [summary.responsible.firstName, summary.responsible.lastName].filter(Boolean).join(" ") || `Demande du ${summary.submittedAt}`;
    button.textContent = `${summary.status === "processed" ? "Traitée — " : ""}${person} — ${summary.site.name}`;
    button.addEventListener("click", async () => {
      try { renderDetail(await api.detail(summary.id)); } catch (error) { handle(error); }
    });
    li.append(button); elements.submissions.append(li);
  }
}

function handle(error) {
  if (error instanceof ApiError && error.status === 403) status("Accès réservé aux responsables.");
  else if (error instanceof ApiError && error.status === 409) { if (error.payload?.latest) renderDetail(error.payload.latest); status("La demande a changé dans LudoHub. La dernière version est affichée."); }
  else if (error instanceof ApiError && error.status === 401) { clearDetail(); show(elements.workspace, false); show(elements.login, true); elements["device-status"].textContent = "Session expirée. Reconnectez cet appareil."; }
  else status("Opération impossible. Réessayez après actualisation.");
}

async function mutate(action) {
  if (!selected) return;
  try { renderDetail(await action(selected)); status("Modification enregistrée dans LudoHub."); }
  catch (error) { handle(error); }
}

function connectFailure(error) {
  if (error?.code === "access_denied") return "Connexion refusée.";
  if (error?.code === "expired_token") return "Le code a expiré. Recommencez.";
  const detail = error?.code || error?.message || "réseau";
  return `Connexion impossible (${detail}).`;
}

async function connect() {
  elements.connect.disabled = true;
  try {
    const device = new DeviceAuth({ origin: config.ludohubOrigin, store: tokenStore(webext), openTab: (url) => webext.tabs.create({ url }) });
    const pending = await device.start();
    elements["device-status"].textContent = `Code ${pending.userCode}. Validez la connexion dans l’onglet LudoHub.`;
    await device.poll(pending, (state) => { elements["device-status"].textContent = state === "slow_down" ? "Validation en attente — fréquence ralentie." : "Validation en attente dans LudoHub…"; });
    await bootAuthenticated();
  } catch (error) {
    elements["device-status"].textContent = connectFailure(error);
  } finally { elements.connect.disabled = false; }
}

async function bootAuthenticated() {
  auth = new AuthenticatedFetch({ origin: config.ludohubOrigin, store: tokenStore(webext) });
  api = new FamilyApi(auth);
  const session = parseSession(await auth.session());
  ludoName = session.ludoName;
  linkedSlug = session.ludoSlug;
  const ludos = await api.ludotheques();
  elements.ludo.replaceChildren();
  for (const ludo of ludos) {
    const option = document.createElement("option");
    option.value = ludo.slug;
    option.textContent = ludo.name;
    if (ludo.logoUrl) option.dataset.logo = ludo.logoUrl;
    if (ludo.address) option.dataset.address = ludo.address;
    if (ludo.phone) option.dataset.phone = ludo.phone;
    if (ludo.email) option.dataset.email = ludo.email;
    if (ludo.website) option.dataset.website = ludo.website;
    elements.ludo.append(option);
  }
  const store = tokenStore(webext);
  const stored = await store.associatedLudo();
  const known = [...elements.ludo.options].some((option) => option.value === stored);
  elements.ludo.value = known ? stored : linkedSlug;
  if (!known) await store.setAssociatedLudo(elements.ludo.value);
  elements["session-label"].textContent = selectedName();
  updateLudoNote();
  show(elements.login, false); show(elements.workspace, true);
  await loadList();
}

elements.connect.addEventListener("click", connect);
elements.ludo.addEventListener("change", () => {
  tokenStore(webext).setAssociatedLudo(selectedSlug()).then(() => {
    elements["session-label"].textContent = selectedName();
    updateLudoNote();
    return loadList();
  }).catch(handle);
});
elements["refresh-list"].addEventListener("click", () => loadList().catch(handle));
elements.logout.addEventListener("click", async () => { clearDetail(); await auth?.logout(); location.reload(); });
async function openPrint(kind) {
  if (!selected || !selectedName()) return;
  const printJob = { submission: selected, kind, ludoName: selectedName(), ludoLogoUrl: selectedLogo() || null, ludoContact: selectedContact() };
  try { await webext.storage.session.set({ printJob }); }
  catch { await webext.storage.local.set({ printJob }); }
  await webext.tabs.create({ url: webext.runtime.getURL("print.html") });
}
elements.process.addEventListener("click", async () => {
  if (!selected) return;
  if (selectedSlug() !== linkedSlug) { status("Le marquage se fait sur la ludothèque liée à ce poste."); return; }
  try {
    const updated = await api.process(selected.id, selected.revision);
    renderDetail(updated);
    const button = document.querySelector(`#submissions button[data-id="${CSS.escape(updated.id)}"]`);
    if (button) button.textContent = `Traitée — ${updated.responsible.firstName} ${updated.responsible.lastName} — ${updated.site.name}`;
    status("Demande marquée comme traitée. Elle reste dans la liste et dans LudoHub.");
  } catch (error) { handle(error); }
});
elements.print.addEventListener("click", () => openPrint("registration").catch(handle));
elements["receipt-cash"].addEventListener("click", () => openPrint("cash-receipt").catch(handle));
elements["receipt-twint"].addEventListener("click", () => openPrint("twint-receipt").catch(handle));
elements.fill.addEventListener("click", async () => {
  if (!selected) return;
  const response = await webext.runtime.sendMessage({ type: "fill-orphee", payload: orpheePayload(selected) });
  status(response?.ok ? "Champs Orphée remplis. Vérifiez-les avant validation." : "Ouvrez une page Orphée autorisée avant le remplissage.");
});
addEventListener("pagehide", clearDetail);

(async () => {
  try {
    config = await loadConfig(webext.runtime);
    const store = tokenStore(webext);
    if (await store.access() || await store.refresh()) await bootAuthenticated();
    else {
      const pending = await store.pending();
      if (pending?.expiresAt > Date.now()) {
        elements["device-status"].textContent = `Code ${pending.userCode}. Validation en attente dans LudoHub…`;
        const device = new DeviceAuth({ origin: config.ludohubOrigin, store });
        await device.poll(pending);
        await bootAuthenticated();
      }
    }
  } catch (error) {
    if (error?.message === "configuration_required") { show(elements.configuration, true); show(elements.login, false); }
    else elements["device-status"].textContent = connectFailure(error);
  }
})();
