import { ApiError, boundFetch, jsonRequest } from "./http.js";

const BASE = "/api/extension/v1";
const PENDING_ERRORS = new Set(["authorization_pending", "slow_down"]);

function base64url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function createVerifier(cryptoImpl = crypto) {
  const bytes = new Uint8Array(64);
  cryptoImpl.getRandomValues(bytes);
  return base64url(bytes);
}

export async function challenge(verifier, cryptoImpl = crypto) {
  return base64url(new Uint8Array(await cryptoImpl.subtle.digest("SHA-256", new TextEncoder().encode(verifier))));
}

function validTokenPair(value) {
  if (!value || typeof value !== "object" || typeof value.accessToken !== "string" || typeof value.refreshToken !== "string") throw new ApiError("invalid_token_response", 502);
  return { accessToken: value.accessToken, refreshToken: value.refreshToken };
}

export class DeviceAuth {
  constructor({ origin, store, fetchImpl = fetch, cryptoImpl = crypto, openTab = null, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)), now = () => Date.now() }) {
    this.origin = origin;
    this.store = store;
    this.fetch = boundFetch(fetchImpl);
    this.crypto = cryptoImpl;
    this.openTab = openTab;
    this.sleep = sleep;
    this.now = now;
  }

  async start() {
    const codeVerifier = createVerifier(this.crypto);
    const codeChallenge = await challenge(codeVerifier, this.crypto);
    const response = await jsonRequest(this.fetch, `${this.origin}${BASE}/device-authorizations`, {
      codeChallenge,
      codeChallengeMethod: "S256",
      clientName: "LudoOrphée",
    });
    if (!response || typeof response.deviceCode !== "string" || typeof response.userCode !== "string" || typeof response.verificationUriComplete !== "string") throw new ApiError("invalid_device_response", 502);
    let verificationUrl;
    try { verificationUrl = new URL(response.verificationUriComplete); } catch { throw new ApiError("invalid_device_response", 502); }
    if (verificationUrl.origin !== this.origin) throw new ApiError("invalid_device_response", 502);
    const interval = Math.max(5, Number(response.interval) || 5);
    const pending = {
      deviceCode: response.deviceCode,
      codeVerifier,
      expiresAt: this.now() + Math.min(600, Number(response.expiresIn) || 600) * 1000,
      interval,
      userCode: response.userCode,
      verificationUriComplete: response.verificationUriComplete,
    };
    await this.store.setPending(pending);
    if (this.openTab) await this.openTab(response.verificationUriComplete);
    return pending;
  }

  async poll(pending, onState = () => {}) {
    let delay = Math.max(5, pending.interval) * 1000;
    while (this.now() < pending.expiresAt) {
      await this.sleep(delay);
      try {
        const tokens = validTokenPair(await jsonRequest(this.fetch, `${this.origin}${BASE}/token`, {
          deviceCode: pending.deviceCode,
          codeVerifier: pending.codeVerifier,
        }));
        await this.store.setTokens(tokens);
        await this.store.clearPending();
        return tokens;
      } catch (error) {
        if (!(error instanceof ApiError) || !PENDING_ERRORS.has(error.code)) {
          await this.store.clearPending();
          throw error;
        }
        if (error.code === "slow_down") delay += 5000;
        onState(error.code);
      }
    }
    await this.store.clearPending();
    throw new ApiError("expired_token", 400);
  }
}

export class AuthenticatedFetch {
  constructor({ origin, store, fetchImpl = fetch, locks = globalThis.navigator?.locks }) {
    this.origin = origin;
    this.store = store;
    this.fetch = boundFetch(fetchImpl);
    this.locks = locks;
    this.refreshing = null;
  }

  async refresh(staleAccessToken = null) {
    if (this.refreshing) return this.refreshing;
    this.refreshing = (async () => {
      if (!this.locks?.request) {
        await this.store.clear();
        throw new ApiError("refresh_lock_unavailable", 503);
      }
      try {
        return await this.locks.request("ludoorphee-refresh", { mode: "exclusive" }, async () => {
          const currentAccessToken = await this.store.access();
          if (staleAccessToken && currentAccessToken && currentAccessToken !== staleAccessToken) return currentAccessToken;
          const refreshToken = await this.store.refresh();
          if (!refreshToken) throw new ApiError("invalid_token", 401);
          const tokens = validTokenPair(await jsonRequest(this.fetch, `${this.origin}${BASE}/refresh`, { refreshToken }));
          await this.store.setTokens(tokens);
          return tokens.accessToken;
        });
      } catch (error) {
        await this.store.clear();
        throw error;
      }
    })().finally(() => { this.refreshing = null; });
    return this.refreshing;
  }

  async request(path, init = {}) {
    let accessToken = await this.store.access();
    if (!accessToken) accessToken = await this.refresh();
    const send = (token) => this.fetch(`${this.origin}${path}`, {
      ...init,
      cache: "no-store",
      headers: { ...(init.headers ?? {}), Authorization: `Bearer ${token}` },
    });
    let response = await send(accessToken);
    if (response.status === 401) response = await send(await this.refresh(accessToken));
    if (response.status === 401) await this.store.clear();
    return response;
  }

  async session() { return (await this.request(`${BASE}/session`).then((r) => r.ok ? r.json() : Promise.reject(new ApiError(`http_${r.status}`, r.status)))); }

  async logout() {
    const token = await this.store.access();
    try {
      if (token) await this.fetch(`${this.origin}${BASE}/logout`, { method: "POST", cache: "no-store", headers: { Authorization: `Bearer ${token}` } });
    } finally {
      await this.store.clear();
    }
  }
}

export function parseSession(value) {
  const session = value?.authenticated === true ? value.session : null;
  if (!session || typeof session.id !== "string" || typeof session.deviceName !== "string" || typeof session.ludoName !== "string" || typeof session.ludoSlug !== "string" || typeof session.memberName !== "string" || !Array.isArray(session.scopes)) throw new ApiError("invalid_session_response", 502);
  return Object.freeze({ id: session.id, deviceName: session.deviceName, ludoName: session.ludoName, ludoSlug: session.ludoSlug, memberName: session.memberName, scopes: Object.freeze([...session.scopes]) });
}
