function text(value, field, max = 500) {
  if (typeof value !== "string" || value.length > max) throw new TypeError(`invalid_${field}`);
  return value;
}
function optional(value, field, max) { return value == null ? null : text(value, field, max); }

export function familySubmission(input) {
  if (!input || typeof input !== "object" || typeof input.id !== "string" || !Number.isInteger(input.revision) || input.revision < 0) throw new TypeError("invalid_submission");
  if ("siteId" in input || "formVersionId" in input) throw new TypeError("legacy_identifier_rejected");
  if (!input.site || typeof input.site.slug !== "string" || typeof input.site.name !== "string") throw new TypeError("invalid_site");
  const members = Array.isArray(input.members) ? input.members.map((member, index) => {
    if (member && "id" in member) throw new TypeError("legacy_member_identifier_rejected");
    return Object.freeze({
    gender: optional(member?.gender, `member_${index}_gender`, 20),
    firstName: text(member?.firstName, `member_${index}_firstName`, 100),
    lastName: text(member?.lastName, `member_${index}_lastName`, 100),
    birthDate: optional(member?.birthDate, `member_${index}_birthDate`, 10),
    });
  }) : [];
  const fee = input.membershipFee;
  if (!fee || !Number.isInteger(fee.amountCents) || fee.amountCents < 0 || fee.currency !== "CHF" || !Array.isArray(fee.allowedMethods)) throw new TypeError("invalid_membershipFee");
  return Object.freeze({
    id: input.id,
    revision: input.revision,
    status: input.status === "processed" ? "processed" : "new",
    submittedAt: text(input.submittedAt, "submittedAt", 40),
    site: Object.freeze({ slug: text(input.site.slug, "site_slug", 100), name: text(input.site.name, "site_name", 200) }),
    responsible: Object.freeze({
      gender: optional(input.responsible?.gender, "gender", 20),
      firstName: text(input.responsible?.firstName, "firstName", 100),
      lastName: text(input.responsible?.lastName, "lastName", 100),
      birthDate: optional(input.responsible?.birthDate, "birthDate", 10),
      address: optional(input.responsible?.address, "address", 500),
      postalCode: optional(input.responsible?.postalCode, "postalCode", 20),
      city: optional(input.responsible?.city, "city", 100),
      phone: optional(input.responsible?.phone, "phone", 50),
      secondaryPhone: optional(input.responsible?.secondaryPhone, "secondaryPhone", 50),
      email: optional(input.responsible?.email, "email", 320),
    }),
    members: Object.freeze(members),
    consent: Object.freeze({
      fullName: optional(input.consent?.fullName, "consentFullName", 200),
      acceptedOn: optional(input.consent?.acceptedOn, "acceptedOn", 10),
      acceptedAt: optional(input.consent?.acceptedAt, "acceptedAt", 40),
      label: text(input.consent?.label, "consentLabel", 1000),
      documents: Object.freeze(Array.isArray(input.consent?.documents) ? input.consent.documents.map((d) => {
        if (!Number.isInteger(d?.version) || d.version < 1) throw new TypeError("invalid_document_version");
        return Object.freeze({ title: text(d?.title, "document_title", 200), version: d.version });
      }) : []),
    }),
    membershipFee: Object.freeze({ amountCents: fee.amountCents, currency: fee.currency, allowedMethods: Object.freeze(fee.allowedMethods.filter((m) => m === "twint" || m === "cash")) }),
    payment: input.payment && (input.payment.method === "twint" || input.payment.method === "cash") ? Object.freeze({ method: input.payment.method, recordedAt: optional(input.payment.recordedAt, "paymentRecordedAt", 40) }) : null,
  });
}
