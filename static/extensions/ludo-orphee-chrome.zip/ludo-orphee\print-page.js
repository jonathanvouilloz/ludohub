import { buildPrintSheet } from "./shared/print.js";

const api = globalThis.chrome ?? globalThis.browser;
const sessionStored = await api.storage.session.get("printJob").catch(() => ({}));
const localStored = await api.storage.local.get("printJob");
const job = sessionStored?.printJob || localStored?.printJob;
if (!job?.submission || !job.ludoName) {
  document.body.textContent = "Aucune fiche à imprimer.";
} else {
  const site = typeof job.ludoContact?.website === "string" ? job.ludoContact.website.replace(/^https?:\/\//i, "").replace(/\/$/, "") : "";
  document.title = site || job.ludoName;
  const sheet = buildPrintSheet(document, job.submission, job.kind, { ludoName: job.ludoName, ludoLogoUrl: job.ludoLogoUrl, ludoContact: job.ludoContact });
  document.body.append(sheet);
  const pending = [...sheet.querySelectorAll("img")].filter((img) => !img.complete);
  const launch = () => window.print();
  if (pending.length === 0) launch();
  else {
    let left = pending.length;
    const done = () => { if (--left === 0) launch(); };
    for (const img of pending) {
      img.addEventListener("load", done, { once: true });
      img.addEventListener("error", done, { once: true });
    }
  }
}
