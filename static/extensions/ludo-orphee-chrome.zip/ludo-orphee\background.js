import { loadConfig, isAllowedUrl } from "./shared/config.js";
import { fillOrpheeDocument } from "./shared/orphee.js";

const api = globalThis.chrome ?? globalThis.browser;
if (api.sidePanel?.setPanelBehavior) api.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
else if (api.sidebarAction?.toggle && api.action?.onClicked) api.action.onClicked.addListener(() => api.sidebarAction.toggle());

api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "fill-orphee" || !message.payload) return false;
  (async () => {
    const config = await loadConfig(api.runtime);
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !isAllowedUrl(tab.url, config.orpheeOrigins)) throw new Error("orphee_url_not_allowed");
    await api.scripting.executeScript({ target: { tabId: tab.id }, func: fillOrpheeDocument, args: [message.payload] });
    sendResponse({ ok: true });
  })().catch((error) => sendResponse({ ok: false, error: error?.message === "orphee_url_not_allowed" ? "orphee_url_not_allowed" : "injection_failed" }));
  return true;
});
