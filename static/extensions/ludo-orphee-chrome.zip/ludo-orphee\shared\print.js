function element(doc, tag, text, className) {
  const node = doc.createElement(tag);
  if (text != null) node.textContent = String(text);
  if (className) node.className = className;
  return node;
}

function frenchLongDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || "");
  if (!match) return "";
  return new Intl.DateTimeFormat("fr-CH", { dateStyle: "long", timeZone: "UTC" }).format(new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]))));
}

export function safeLogoUrl(value) {
  if (typeof value !== "string" || value.length > 500) return null;
  let url;
  try { url = new URL(value); } catch { return null; }
  if (url.protocol !== "https:" || url.username || url.password) return null;
  return url.href;
}

function logoFrame(doc, src, alt, className) {
  const frame = element(doc, "span", null, "logo-frame");
  const image = element(doc, "img", null, className);
  image.src = src;
  image.alt = alt;
  frame.append(image);
  return frame;
}

function header(doc, ludoName, logoUrl, siteName) {
  const node = element(doc, "header", null, "print-header");
  const logos = element(doc, "div", null, "brand-logos");
  logos.append(logoFrame(doc, "assets/ville-ge.png", "Ville de Genève", "city-logo"));
  const ludoLogo = safeLogoUrl(logoUrl);
  if (ludoLogo) logos.append(logoFrame(doc, ludoLogo, ludoName, "ludo-logo"));
  const title = element(doc, "div", null, "brand-title");
  title.append(element(doc, "p", ludoName, "brand-name"));
  if (siteName && siteName !== ludoName) title.append(element(doc, "p", siteName, "brand-site"));
  node.append(logos, title);
  return node;
}

function facts(doc, pairs) {
  const list = element(doc, "dl", null, "facts");
  for (const [label, value, className] of pairs) {
    list.append(element(doc, "dt", label), element(doc, "dd", value || "—", className));
  }
  return list;
}

function memberTable(doc, members) {
  const table = element(doc, "table", null, "member-table");
  const head = element(doc, "tr");
  for (const label of ["Prénom", "Nom"]) head.append(element(doc, "th", label));
  table.append(head);
  for (const member of members) {
    const row = element(doc, "tr");
    for (const value of [member.firstName, member.lastName]) row.append(element(doc, "td", value || "—"));
    table.append(row);
  }
  return table;
}

function websiteLabel(value) {
  if (typeof value !== "string") return "";
  return value.trim().replace(/^https?:\/\//i, "").replace(/\/$/, "");
}

function contactFooter(doc, contact) {
  const node = element(doc, "footer", null, "ludo-contact");
  const bits = [contact?.address, contact?.phone, contact?.email].filter((part) => typeof part === "string" && part.trim());
  if (bits.length) node.append(element(doc, "p", bits.join("  ·  ")));
  const site = websiteLabel(contact?.website);
  if (site) node.append(element(doc, "p", site, "ludo-website"));
  return node;
}

function signRow(doc, signatureDate) {
  const row = element(doc, "div", null, "sign-row");
  const date = element(doc, "p", null, "sign-date");
  date.append(element(doc, "span", "Date"), element(doc, "strong", signatureDate || "—"));
  const signature = element(doc, "p", null, "sign-signature");
  signature.append(element(doc, "span", "Signature"), element(doc, "span", null, "sign-line"));
  row.append(date, signature);
  return row;
}

function personFacts(submission) {
  const person = submission.responsible;
  return [
    ["Adhérent", `${person.firstName} ${person.lastName}`.trim()],
    ["Adresse", [person.address, person.postalCode, person.city].filter(Boolean).join(", ")],
    ["Téléphone", [person.phone, person.secondaryPhone].filter(Boolean).join(" · ")],
    ["E-mail", person.email],
  ];
}

function receiptCopy(doc, submission, kind, audience, ludoName, logoUrl, signatureDate, contact) {
  const twint = kind === "twint-receipt";
  const copy = element(doc, "article", null, "receipt-copy");
  copy.append(header(doc, ludoName, logoUrl, submission.site?.name));
  copy.append(element(doc, "p", audience, "copy-mark"));
  copy.append(element(doc, "h1", twint ? "Quittance de paiement TWINT" : "Quittance de paiement en espèces"));
  copy.append(facts(doc, [
    ...personFacts(submission),
    ["Montant", `${(submission.membershipFee.amountCents / 100).toFixed(2)} ${submission.membershipFee.currency}`, "emphasis"],
    ["Paiement", twint ? "TWINT" : "Espèces", "emphasis"],
  ]));
  copy.append(signRow(doc, signatureDate), contactFooter(doc, contact));
  return copy;
}

export function buildPrintSheet(doc, submission, kind = "registration", options = {}) {
  if (typeof options.ludoName !== "string" || !options.ludoName.trim()) throw new TypeError("ludo_name_required");
  const date = options.date instanceof Date ? options.date : new Date();
  const dateText = new Intl.DateTimeFormat("fr-CH", { dateStyle: "long" }).format(date);
  const sheet = element(doc, "section", null, "print-sheet");
  sheet.id = "print-sheet";
  const signatureDate = frenchLongDate(submission.consent?.acceptedOn) || dateText;
  if (kind === "twint-receipt" || kind === "cash-receipt") {
    sheet.className = "print-sheet receipt-sheet";
    sheet.append(receiptCopy(doc, submission, kind, "Exemplaire client", options.ludoName, options.ludoLogoUrl, signatureDate, options.ludoContact));
    sheet.append(receiptCopy(doc, submission, kind, "Exemplaire interne", options.ludoName, options.ludoLogoUrl, signatureDate, options.ludoContact));
    return sheet;
  }
  const person = submission.responsible;
  sheet.append(header(doc, options.ludoName, options.ludoLogoUrl, submission.site?.name));
  sheet.append(element(doc, "h1", "Fiche d’adhésion familiale"));
  sheet.append(facts(doc, [
    ["Nom", person.lastName],
    ["Prénom", person.firstName],
    ["Adresse", [person.address, person.postalCode, person.city].filter(Boolean).join(", ")],
    ["Téléphone", [person.phone, person.secondaryPhone].filter(Boolean).join(" · ")],
    ["E-mail", person.email],
  ]));
  if (submission.members.length > 0) {
    const members = element(doc, "section", null, "sheet-block");
    members.append(element(doc, "h2", "Membres du foyer"), memberTable(doc, submission.members));
    sheet.append(members);
  }
  const consent = element(doc, "section", null, "sheet-block");
  consent.append(element(doc, "h2", "Consentement enregistré"));
  consent.append(element(doc, "p", submission.consent.label));
  consent.append(facts(doc, [["Accepté par", submission.consent.fullName]]));
  const docs = element(doc, "ul");
  for (const snapshot of submission.consent.documents) docs.append(element(doc, "li", `${snapshot.title} — version ${snapshot.version}`));
  consent.append(docs);
  sheet.append(consent, signRow(doc, signatureDate), contactFooter(doc, options.ludoContact));
  return sheet;
}

export function printSubmission(doc, win, submission, kind, options) {
  doc.getElementById("print-sheet")?.remove();
  const sheet = buildPrintSheet(doc, submission, kind, options);
  doc.body.append(sheet);
  const cleanup = () => sheet.remove();
  win.addEventListener("afterprint", cleanup, { once: true });
  win.print();
  return cleanup;
}
