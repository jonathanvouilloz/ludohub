export class ApiError extends Error {
  constructor(code, status, payload = null) {
    super(code);
    this.code = code;
    this.status = status;
    this.payload = payload;
  }
}

export async function readJson(response) {
  let body = null;
  try { body = await response.json(); } catch { /* réponse vide ou invalide */ }
  if (!response.ok) throw new ApiError(typeof body?.error === "string" ? body.error : `http_${response.status}`, response.status, body);
  return body;
}

export function boundFetch(fetchImpl = globalThis.fetch) {
  return (url, init) => fetchImpl.call(globalThis, url, init);
}

export function jsonRequest(fetchImpl, url, body, init = {}) {
  return fetchImpl(url, {
    ...init,
    method: init.method ?? "POST",
    cache: "no-store",
    headers: { "Content-Type": "application/json", ...(init.headers ?? {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  }).then(readJson);
}
