function area(api, name) {
  const selected = api?.storage?.[name];
  if (!selected) throw new Error(`storage_${name}_unavailable`);
  return selected;
}

function invoke(target, method, arg) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      if (error) reject(error instanceof Error ? error : new Error(String(error)));
      else resolve(value);
    };
    try {
      const result = target[method](arg, (value) => {
        const runtimeError = globalThis.chrome?.runtime?.lastError;
        finish(runtimeError ? new Error(runtimeError.message) : null, value);
      });
      if (result?.then) result.then((value) => finish(null, value), finish);
    } catch (error) {
      finish(error);
    }
  });
}

export function tokenStore(api = globalThis.chrome ?? globalThis.browser) {
  const session = area(api, "session");
  const local = area(api, "local");
  return Object.freeze({
    async access() {
      try {
        const token = (await invoke(session, "get", "accessToken"))?.accessToken ?? null;
        if (token) return token;
      } catch { /* la zone session peut refuser l'écriture dans le panneau */ }
      return (await invoke(local, "get", "accessToken"))?.accessToken ?? null;
    },
    async refresh() { return (await invoke(local, "get", "refreshToken"))?.refreshToken ?? null; },
    async pending() { return (await invoke(local, "get", "pendingDeviceAuth"))?.pendingDeviceAuth ?? null; },
    async associatedLudo() { return (await invoke(local, "get", "associatedLudo"))?.associatedLudo ?? null; },
    async setAssociatedLudo(slug) { await invoke(local, "set", { associatedLudo: slug }); },
    async setPending(value) { await invoke(local, "set", { pendingDeviceAuth: value }); },
    async clearPending() { await invoke(local, "remove", "pendingDeviceAuth"); },
    async setTokens(tokens) {
      await invoke(local, "set", { refreshToken: tokens.refreshToken });
      try {
        await invoke(session, "set", { accessToken: tokens.accessToken });
      } catch {
        await invoke(local, "set", { accessToken: tokens.accessToken });
      }
    },
    async clear() {
      await Promise.all([
        invoke(session, "remove", "accessToken").catch(() => {}),
        invoke(local, "remove", ["accessToken", "refreshToken", "pendingDeviceAuth"]),
      ]);
    },
  });
}
