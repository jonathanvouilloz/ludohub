import { ApiError, readJson } from "./http.js";
import { familySubmission } from "./model.js";

const BASE = "/api/extension/v1/family-memberships";

function idPath(id) {
  if (typeof id !== "string" || !/^[A-Za-z0-9_-]{1,100}$/.test(id)) throw new TypeError("invalid_id");
  return `${BASE}/${encodeURIComponent(id)}`;
}

function revision(value) {
  if (!Number.isInteger(value) || value < 0) throw new TypeError("invalid_revision");
  return value;
}

export class FamilyApi {
  constructor(authenticatedFetch) { this.http = authenticatedFetch; this.ludoSlug = null; }

  async list({ status, cursor, ludo } = {}) {
    const query = new URLSearchParams();
    if (status === "new" || status === "processed") query.set("status", status);
    if (typeof cursor === "string" && cursor) query.set("cursor", cursor);
    const selected = ludo ?? this.ludoSlug;
    if (typeof selected === "string" && /^[a-z0-9](?:[a-z0-9-]{0,78}[a-z0-9])?$/.test(selected)) query.set("ludo", selected);
    const response = await this.http.request(`${BASE}${query.size ? `?${query}` : ""}`);
    const body = await readJson(response);
    if (!Array.isArray(body?.submissions)) throw new ApiError("invalid_list_response", 502);
    return {
      ...body,
      submissions: body.submissions.map((item) => {
        if (!item || typeof item.id !== "string" || "siteId" in item || !item.site || typeof item.site.slug !== "string" || typeof item.site.name !== "string" || typeof item.submittedAt !== "string" || !item.responsible || typeof item.responsible.firstName !== "string" || typeof item.responsible.lastName !== "string" || !Number.isInteger(item.revision)) throw new ApiError("invalid_list_response", 502);
        return Object.freeze({ id: item.id, site: Object.freeze({ slug: item.site.slug, name: item.site.name }), submittedAt: item.submittedAt, responsible: Object.freeze({ firstName: item.responsible.firstName, lastName: item.responsible.lastName, email: item.responsible.email ?? null }), status: item.status, payment: item.payment ?? null, revision: item.revision, processedAt: item.processedAt ?? null });
      }),
    };
  }

  async ludotheques() {
    const body = await readJson(await this.http.request("/api/extension/v1/ludotheques"));
    if (!Array.isArray(body?.ludos)) throw new ApiError("invalid_ludo_list", 502);
    return body.ludos.map((ludo) => {
      if (!ludo || typeof ludo.slug !== "string" || typeof ludo.name !== "string") throw new ApiError("invalid_ludo_list", 502);
      const logoUrl = typeof ludo.logoUrl === "string" && /^https:\/\/\S+$/.test(ludo.logoUrl) ? ludo.logoUrl : null;
      const detail = (value, max) => typeof value === "string" && value.trim() && value.trim().length <= max ? value.trim() : null;
      return Object.freeze({ slug: ludo.slug, name: ludo.name, logoUrl, address: detail(ludo.address, 300), phone: detail(ludo.phone, 50), email: detail(ludo.email, 320), website: detail(ludo.website, 300) });
    });
  }

  async detail(id, ludo) {
    const selected = ludo ?? this.ludoSlug;
    const query = typeof selected === "string" && selected ? `?ludo=${encodeURIComponent(selected)}` : "";
    const body = await readJson(await this.http.request(`${idPath(id)}${query}`));
    return familySubmission(body?.submission);
  }

  async mutate(id, action, expectedRevision, extra = {}) {
    const response = await this.http.request(`${idPath(id)}/${action}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ expectedRevision: revision(expectedRevision), ...extra }),
    });
    if (response.status === 409) {
      const latest = await this.detail(id);
      throw new ApiError("conflict", 409, { latest });
    }
    const body = await readJson(response);
    return familySubmission(body?.submission);
  }

  process(id, expectedRevision) { return this.mutate(id, "process", expectedRevision); }

  payment(id, expectedRevision, paymentMethod) {
    if (paymentMethod !== "twint" && paymentMethod !== "cash") throw new TypeError("invalid_payment_method");
    return this.mutate(id, "payment", expectedRevision, { method: paymentMethod });
  }
}
